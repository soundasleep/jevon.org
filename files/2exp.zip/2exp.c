//
// Calculate the precise value of 2^MAX (defined below).
//
// If the buffer size starts to approach 100%, you will have to increase
// the buffer size (BUFSIZE).
//	
// Jevon Wright 2002
//   http://www.jevon.org
//   support@jevon.org
//
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MILLION 1000000
#define BUFSIZE 1000000
#define WAIT_INTERVAL 25000
#define MAX 1000

typedef char STR[80];

int main(void)
{
	int buf[BUFSIZE];
	int max, i, j, carryover, startfrom = BUFSIZE-2;
	STR output_fn = "c:\\documents and settings\\jevon\\desktop\\2exp.txt";
	FILE *fp;

	for (j = 0; j < BUFSIZE; j++)
		buf[j] = 0;
	buf[BUFSIZE-1] = 2;
	
	for (i = 1; i < MAX; i++)
	{
		carryover = 0;
		for (j = BUFSIZE - 1; j >= startfrom && (buf[j] != 0 || carryover != 0); j--)
		{
			buf[j] = (buf[j] << 1) + carryover;
			if (buf[j] > MILLION)
			{
				carryover = 1; // buf[j] / MILLION;
				buf[j] = buf[j] - MILLION; // % MILLION;
				if (j > 0 && buf[j-1] == 0)
					startfrom--;
			} else carryover = 0;
		}
		
		if (i % WAIT_INTERVAL == 0)
			printf("done: %8d / %8d [%5.1f%%] buffer filled: [%5.1f%%]\n", i, MAX, ((float)i/(float)MAX)*100, ((float)(BUFSIZE-j-1)/(float)BUFSIZE)*100);
	}
	
	// print to file! :D
	printf("Printing to file...\n\n");
	fp = fopen(output_fn, "w");
	if (fp == NULL)
		printf("Error: could not open file!\n");
	else
	{
		fprintf(fp, "2^%d=\n", MAX);
		for (j = 0; j < BUFSIZE; j++)
			if (buf[j] != 0)
				if (j > 0 && buf[j-1] == 0)
					fprintf(fp, "%6d", buf[j]);
				else
					fprintf(fp, "%06d", buf[j]);
		fprintf(fp, "\ntime taken: %f sec\n", clock() / CLOCKS_PER_SEC);
		fclose(fp);
	}
	
	// now, print out result
	/*
	for (j = 0; j < BUFSIZE; j++)
		if (buf[j] != 0) 
			if (j > 0 && buf[j-1] == 0)
				printf("%6d", buf[j]);
			else
				printf("%06d", buf[j]);
	printf("\n"); 
	*/
	
	printf("time taken: %f sec\n", clock() / CLOCKS_PER_SEC);
	
	return 0;
}
