DC++ Upload Counter 1.0.1: 8 December 2002
Copyright (c) Jevon Wright 2002
All Rights Reserved
--------------------------------

This program is a tool to take your DC++ uploads log and generate
statistics about your completed uploads.

This program will only work on DC++ (and I have only tested it on
versions 0.18 to 0.20). It also assumes that your uploads log is
called "Uploads.log".

To install this program, extract the two files in the zip file to the
same directory that you have your Uploads.log in.

To run the program, just run the .exe.

To uninstall the program, just delete the .exe and this readme.txt
from your logs directory.

--------------------------------
This program requires certain Visual Basic custom controls to be 
installed on your system. These files are not included by default. You
can download them from the website at:
  http://www.jevon.org
  
The files you require are:
  Visual Basic 6.0 Runtimes             vbrun60sp5.exe
  Microsoft Common Controls             mscomctl.ocx

To install the VB6 runtimes, simply run the executable.
To install the "mscomctl.ocx", you will need to copy the file to your
Windows "SYSTEM" folder (make sure you backup any files that might be
overwritten!). Then you may need to register these controls, by
going Start > Run..., and entering in the following:

  regsvr32 <your windows systemdirectory>\mscomctl.ocx
 
For example, if you are running Windows XP and you wish to register
the "mscomctl.ocx" file, you will need to type

  regsvr32 C:\WINDOWS\SYSTEM32\MSCOMCTL.OCX

--------------------------------
To contact the author of this software (Jevon Wright), you can either
e-mail me at support@jevon.org, or visit my web site at
  http://www.jevon.org/

If you have any support queries, or thoughts of things that should be
added, bug requests, anything; please post them on the forums at
  http://forums.jevon.org/
