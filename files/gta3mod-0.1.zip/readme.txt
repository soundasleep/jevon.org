GTA3 Mod 0.1.5: 29 October 2002
Copyright (c) Jevon Wright 2002
All Rights Reserved


1. About GTA3 Mod
2. How to install
3. How to uninstall
4. Required files
5. Legal stuff
6. Contacting the author


------------------------------------------------------------------------
1. ABOUT GTA3 MOD

This program is a tool to help you modify some of the Grand Theft Auto
3 (PC version) data files, to allow you to do some crazy things in
GTA3. Some of the things I have been able to do so far is:

  - Make (almost) indestructable, high speed, heavy police cars (which
    mow down ANYTHING in its way);
  - Crazy stunt cars which spin out of control and can manage to
    jump from one island to another, doing 36000 degree rotations;

Future versions of this program may allow you to do other modifications,
such as:

  - Creating super weapons, such as an uzi which kills *anything* (cars,
    people) with one shot;
  - Modifying weapon and pedestrian personalities;
  - Perhaps even change the colours of the cars and/or environment...
  - And probably more... heh :D
  
But please note, this is developmental software. BACK UP EVERYTHING!
Also, while playing with modified stuff, it is incredibly more likely
that your copy of GTA3 will crash. My copy crashes a lot with the
modifications that I have created.

For up-to-date information about GTA3 Mod, please visit my website at
  http://www.jevon.org
and regularily browse the forums at
  http://forums.jevon.org
  
Above all, enjoy making modifications. :D

Jevon


------------------------------------------------------------------------
2. HOW TO INSTALL

This program comes in a compressed ZIP file. Use any uncompression
utility, such as WinZip (www.winzip.com), to open it. Extract the files
in the compressed file to any folder.

When you run GTA3Mod for the first time, it will prompt you for the
location of your GTA3 data files. These are commonly in the \data
subfolder of your GTA3 installation directory. For example, if you
installed GTA3 to c:\games\gta3\, your data directory would
be in c:\games\gta3\data\.


** WARNING **
This program modifies your GTA3 data files! Although I have tested this
piece of software enough to feel reasonably confident that it will work
in the real world, PLEASE BACKUP YOUR FILES, in particular all the files
in the /data directory. I assume no responsibility for any damage that
this piece of software may cause!


This program has been verified to work with an unpatched copy of GTA3.
I am not sure what the results are if you run the modifications on a
patched version of GTA3.


------------------------------------------------------------------------
3. HOW TO UNINSTALL

To uninstall, just delete the GTA3 Mod files.


------------------------------------------------------------------------
4. REQUIRED FILES

This program requires certain Visual Basic custom controls to be 
installed on your system. These files are not included by default. You
can download them from the website at:
  http://www.jevon.org
  
The files you require are:
  Visual Basic 6.0 Runtimes             vbrun60sp5.exe
  Microsoft Common Controls             mscomctl.ocx

To install the VB6 runtimes, simply run the executable.
To install the "mscomctl.ocx", you will need to copy the file to your
Windows "SYSTEM" folder (make sure you backup any files that might be
overwritten!). Then you may need to register these controls, by
going Start > Run..., and entering in the following:

  regsvr32 <your windows systemdirectory>\mscomctl.ocx
 
For example, if you are running Windows XP and you wish to register
the "mscomctl.ocx" file, you will need to type

  regsvr32 C:\WINDOWS\SYSTEM32\MSCOMCTL.OCX


------------------------------------------------------------------------
5. LEGAL STUFF

Please read the included license file! (license.txt)

Basically, I can't be held responsible for what happens with this
program. It's developmental and most likely unstable and buggy. It's
made completely for having some fun with your copy of GTA3.

I am not affiliated with Rockstar Games in any way, and the
modifications that you will be doing to your copy of GTA3 are completely
unsupported.


------------------------------------------------------------------------
6. CONTACTING THE AUTHOR

To contact the author of this software (Jevon Wright), you can either
e-mail me at support@jevon.org, or visit my web site at
  http://www.jevon.org/

If you have any support queries, or thoughts of things that should be
added, bug requests, anything; please post them on the forums at
  http://forums.jevon.org/